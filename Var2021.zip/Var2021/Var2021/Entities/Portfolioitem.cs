﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Var2021.Entities
{
    class Portfolioitem
    {
        public string Index { get; set; }
        public decimal Volume { get; set; }
    }
}
